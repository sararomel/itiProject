import React from 'react'

function News() {
  return (
    <h1 className='text-center'>New Component Works fine </h1>
  )
}

export default News
