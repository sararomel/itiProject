import React from 'react'

function Projects() {
  return (
    <h1 className='text-center'>Project Component Works fine</h1>
  )
}

export default Projects
