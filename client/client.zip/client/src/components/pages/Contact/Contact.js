import React from 'react';
import "./Contact.css";
import Login from '../../Login/Login';
function Contact(){
    return(
      <div>
        <Login />
      </div>
    )}

export default Contact;